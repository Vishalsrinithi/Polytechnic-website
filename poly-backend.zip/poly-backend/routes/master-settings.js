var express = require('express');
var router = express.Router();
var dataQuery = require('../references/data-query')

router.get('/getCollegeInfo', function (req, res, next) {
    dataQuery.getCollegeInfo(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updateCollegeInfo', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updateCollegeInfo(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});


//user_role_assignment
router.get('/getrole_assign', function (req, res, next) {
    dataQuery.getrole_assign(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updaterole_assign', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updaterole_assign(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

//user_role

router.get('/getuser_role', function (req, res, next) {
    dataQuery.getuser_role(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updateuser_role', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updateuser_role(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

//master_department

router.get('/getmaster_dept', function (req, res, next) {
    dataQuery.getmaster_dept(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updatemaster_dept ', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updatemaster_dept (JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

//child_department 


router.get('/getchild_dept', function (req, res, next) {
    dataQuery.getchild_dept(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});


router.post('/updatechild_dept ', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updatechild_dept(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

//user details
router.get('/getuser_details', function (req, res, next) {
    dataQuery.getuser_details(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updateuser_details', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updateuser_details(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

//user login
router.get('/getuser_logins', function (req, res, next) {
    dataQuery.getuser_logins(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updateuser_logins', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updateuser_logins(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

//CHILD_PROGRAMME
router.get('/getchild_programme', function (req, res, next) {
    dataQuery.getchild_programme(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updatechild_programmed', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updatechild_programm(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});
//MASTER_PROGRAMME
router.get('/getmaster_programme', function (req, res, next) {
    dataQuery.getmaster_programme(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updatemaster_programme', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updatemaster_programme(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

//MASTER_SCHEME
router.get('/getmaster_scheme', function (req, res, next) {
    dataQuery.getmaster_scheme(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updatemaster_scheme', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updatemaster_scheme(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

//CHILD_BATCH
router.get('/getchild_batch', function (req, res, next) {
    dataQuery.getchild_batch(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updatechild_batch', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updatechild_batch(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

//MASTER_BATCH
router.get('/getmaster_batch', function (req, res, next) {
    dataQuery.getmaster_batch(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updatemaster_batch', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updatemaster_batch(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

//USERS
router.get('/getusers', function (req, res, next) {
    dataQuery.getusers(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});

router.post('/updateusers', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updateusers(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});


//user_combined

router.get('/getuser_info', function (req, res, next) {
    dataQuery.getuser_info(function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});


router.post('/updateuser_info', function (req, res, next) {
    let bodyParam = req.body;
    dataQuery.updateuser_info(JSON.stringify(bodyParam), function (err, rows) {
        if (err) {
            res.send(err);
        } else {
            res.send(rows[0]);
        }
    });
});


module.exports = router;