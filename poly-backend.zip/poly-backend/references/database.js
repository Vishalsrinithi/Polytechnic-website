var mysql = require("mysql2");

var connection = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "root",
  database: "polytechnic",
  port: "3308",
});

module.exports = connection;
